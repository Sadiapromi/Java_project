package interfaces;

import java.lang.*;
import classes.*;

public interface IQuantity
{
	boolean addQuantity(int amount);
	boolean sellQuantity(int amount);
}